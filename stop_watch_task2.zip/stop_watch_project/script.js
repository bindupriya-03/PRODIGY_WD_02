let startTime = 0;
let elapsedTime = 0;
let intervalId;
let running = false;

const display = document.getElementById("display");
const laps = document.getElementById("laps");
document.getElementById("start").onclick = () => {
    if (!running) {
        running = true;
        startTime = Date.now() - elapsedTime;

        intervalId = setInterval(() => {
            elapsedTime = Date.now() - startTime;
            display.innerText = formatTime(elapsedTime);
        }, 10);
    }
};
document.getElementById("pause").onclick = () => {
    running = false;
    clearInterval(intervalId);
};
document.getElementById("reset").onclick = () => {
    running = false;
    clearInterval(intervalId);
    elapsedTime = 0;
    display.innerText = "00:00:00.00";
    laps.innerHTML = "";
};
document.getElementById("lap").onclick = () => {
    if (running) {
        const li = document.createElement("li");
        li.textContent = formatTime(elapsedTime);
        laps.appendChild(li);
    }
};
document.getElementById("clearLaps").onclick = () => {
    laps.innerHTML = "";
};
function formatTime(ms) {
    let milliseconds = Math.floor((ms % 1000) / 10);
    let seconds = Math.floor((ms / 1000) % 60);
    let minutes = Math.floor((ms / (1000 * 60)) % 60);
    let hours = Math.floor(ms / (1000 * 60 * 60));

    return (
        String(hours).padStart(2, '0') + ":" +
        String(minutes).padStart(2, '0') + ":" +
        String(seconds).padStart(2, '0') + "." +
        String(milliseconds).padStart(2, '0')
    );
}
const toggle = document.getElementById("modeToggle");

toggle.onclick = () => {
    document.body.classList.toggle("light-mode");
};
