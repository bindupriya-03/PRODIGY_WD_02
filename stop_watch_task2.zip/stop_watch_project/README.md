# ⏱️ Stopwatch Web Application  
### Task-02 — Prodigy Infotech Web Development Internship  
**Developed by: Bindupriya Gajendrula**

## 📌 Project Overview  
This project is a fully functional **Stopwatch Web Application** built as **Task-02** for the **Prodigy Infotech Web Development Internship**.

It is designed using **HTML**, **CSS**, and **JavaScript**, providing a clean, modern, and responsive user interface.  
The stopwatch allows users to track time accurately, record lap times, and switch between dark/light modes.
## 🚀 Features  
### ⏱️ Stopwatch Functionalities  
- Start the stopwatch  
- Pause the stopwatch  
- Reset the stopwatch  
- Record lap times  
- Clear all laps  
- High-precision time tracking  

### 🎨 UI & Experience  
- Modern and responsive design  
- Smooth animations  
- Clean layout with proper spacing  
- Works on all screen sizes  

### 🌗 Dark / Light Mode  
- Toggle between **dark mode** and **light mode** with one click  

### 📄 Additional Pages  
- **Home Page**  
- **Stopwatch Page**  
- **About Page**  
- **Contact Page**  

---

## 🛠️ Technologies Used  
- **HTML** – Structure  
- **CSS** – Styling and layout  
- **JavaScript** – Stopwatch functionality  

---

## 📂 Folder Structure  

```
Stopwatch-WebApp/
│── index.html
│── stopwatch.html
│── about.html
│── contact.html
│── style.css
│── script.js
│── README.md
│── assets/ (optional)
```

---

## 📸 Screenshots  
(You can add screenshots after running your project)

```
/assets/homepage.png  
/assets/stopwatch.png  
/assets/about.png  
/assets/contact.png
```

---

## ▶️ How to Run  
1. Download or clone this repository  
2. Open `index.html` in any browser  
3. Navigate to the Stopwatch page  
4. Enjoy the features!

---

## 🙋‍♀️ Developer  
**Bindupriya Gajendrula**  
Web Development Intern  
Prodigy Infotech – Task-02  

---

## 🏢 Internship  
This project is created as part of the  
**Prodigy Infotech Web Development Internship Program (Task-02)**.

---

## ⭐ If you like this project  
Feel free to **star ⭐ the repository** on GitHub!  
Your support is appreciated 😊

---

# Thank You!  
